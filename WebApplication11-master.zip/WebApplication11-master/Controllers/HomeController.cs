﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication11.Models;

namespace WebApplication11.Controllers
{
    public class HomeController : Controller
    {
        rihanEntities4 db = new rihanEntities4();
        
        public ActionResult Index()
        {
            
            
              var res = db.ahmadls.ToList();
                return View(res);
            

           
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult create()
        {
                return View();
        }
        [HttpPost]
        public ActionResult create(ahmadl obj)
        {
            if (obj.Id == 0)
            {
                db.ahmadls.Add(obj);
                db.SaveChanges();
            }
            else
            {
                db.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("index");
        }
        public ActionResult delete(int? id)
        {
            var delete = db.ahmadls.Where(m => m.Id == id).First();
            db.ahmadls.Remove(delete);
            db.SaveChanges();
            return RedirectToAction("index");
        }
        public ActionResult edit(int? id)
        {
            var edit = db.ahmadls.Where(m => m.Id == id).First();
            return View( "create", edit);
        }


    }
}